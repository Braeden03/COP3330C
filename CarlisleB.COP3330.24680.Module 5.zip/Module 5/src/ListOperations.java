// Braeden Carlisle
// COP-3330C-24680
// For this assignment we were asked to create a program that asks users to input a list of 8 words in which the program takes that list and shuffles it as well as sorts it. For my 2 other static methods, I chose a min and max value. We were then asked to convert the list into an array and then back into a list. Lastly, we had to describe the difference between Collections and Collection. 
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class ListOperations {
    public static void main(String[] args) {
        // Task 1: Create a List
        List<String> dataList = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        // Allow user to add eight pieces of data without duplicates
        while (dataList.size() < 8) {
            System.out.print("Enter a word: ");
            String input = scanner.next();
            if (!dataList.contains(input.toLowerCase())) {
                dataList.add(input.toLowerCase());
            } else {
                System.out.println("Duplicate entry. Try again.");
            }
        }

        // Task 2: Print the List
        System.out.println("\nList:");
        for (String data : dataList) {
            System.out.println(data);
        }

        // Print total number, longest, and shortest entry
        System.out.println("Total entries: " + dataList.size());
        System.out.println("Longest entry: " + findLongestEntry(dataList));
        System.out.println("Shortest entry: " + findShortestEntry(dataList));

        // Task 3: Sort the List
        Collections.sort(dataList);
        System.out.println("\nSorted List:");
        printListWithHeader(dataList, "List has been sorted.");

        // Task 4: Custom Sort the List
        Collections.sort(dataList, (s1, s2) -> s2.length() - s1.length());
        System.out.println("\nSorted by Character Length:");
        printListWithHeader(dataList, "List has been sorted by character length.");

        // Task 5: Shuffle the List
        Collections.shuffle(dataList);
        System.out.println("\nShuffled List:");
        printListWithHeader(dataList, "List has been shuffled.");

        // Task 6: Search the List
        System.out.print("\nEnter a word to search for: ");
        String searchWord = scanner.next().toLowerCase();
        int index = dataList.indexOf(searchWord);
        if (index != -1) {
            System.out.println("Word found at index: " + index);
        } else {
            System.out.println("Word not found in the list.");
        }

        // Task 7: Implement at least 2 other static methods from the Collections class
        System.out.println("\nMax value: " + Collections.max(dataList));
        System.out.println("Min value: " + Collections.min(dataList));

        // Task 8: Convert the List to an Array
        String[] dataArray = dataList.toArray(new String[0]);
        System.out.println("\nArray from List:");
        printArrayWithHeader(dataArray, "Elements of the array:");

        // Task 9: Convert the array back into a list
        List<String> newList = new ArrayList<>(List.of(dataArray));
        System.out.println("\nList from Array:");
        printListWithHeader(newList, "Elements of the list:");

        // Task 10: Comment on Collections vs. Collection
        /*
         * Collections is a utility class in Java that provides various
         * methods for working with collections such as List, Set, Map. It contains
         * static methods like sort(), shuffle(), max(), and min(), for dealing with
         * collections.
         *
         * Collection is an interface in the Java Collections
         * Framework. It is the root interface for all the collection types such as a
         * List, Set, Queue. It defines the basic methods that all collections should
         * have, like add(), remove(), size(), etc.
         *
         * In summary, Collections is a utility class that provides static methods to
         * work with collections, while Collection is an interface that defines
         * methods for collection types.
         */
    }

    // Additional method to find the longest entry
    private static String findLongestEntry(List<String> list) {
        return Collections.max(list, (s1, s2) -> s1.length() - s2.length());
    }

    // Additional method to find the shortest entry
    private static String findShortestEntry(List<String> list) {
        return Collections.min(list, (s1, s2) -> s1.length() - s2.length());
    }

    // Additional method to print a list with a header
    private static void printListWithHeader(List<String> list, String header) {
        System.out.println(header);
        for (String data : list) {
            System.out.println(data);
        }
    }

    // Additional method to print an array with a header
    private static void printArrayWithHeader(String[] array, String header) {
        System.out.println(header);
        for (String data : array) {
            System.out.println(data);
        }
    }
}
